BASKARA AI LIVE — PETUNJUK SINGKAT

Isi paket:
- index.html: tampilan chat Baskara AI
- netlify.toml: konfigurasi deploy Netlify
- netlify/functions/chat.js: backend yang memanggil OpenAI API

PENTING:
1. Chat sungguhan butuh OpenAI API key dan billing API yang aktif. Langganan ChatGPT tidak otomatis mencakup biaya API.
2. Jangan masukkan API key ke index.html atau bagikan di chat.
3. Di Netlify, buka Site configuration / Environment variables, tambah:
   Key: OPENAI_API_KEY
   Value: API key milikmu
4. Deploy folder ini ke Netlify. Pastikan folder netlify/functions ikut ter-upload.
5. Setelah mengubah environment variable, lakukan deploy ulang.

API key bisa dibuat di https://platform.openai.com/api-keys
