exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Gunakan metode POST." }) };
  }
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "OPENAI_API_KEY belum dipasang di Netlify." }) };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const input = messages.map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: [{ type: "input_text", text: String(m.content || "") }]
    }));
    const resp = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-5-mini",
        instructions: "Kamu adalah Baskara AI, asisten yang ramah, membantu, dan menjawab dalam bahasa yang dipakai pengguna. Jika pengguna memakai bahasa Indonesia santai, balas dengan bahasa Indonesia yang natural.",
        input
      })
    });
    const result = await resp.json();
    if (!resp.ok) {
      return { statusCode: resp.status, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: result.error?.message || "Permintaan API gagal." }) };
    }
    const reply = (result.output || []).flatMap(item => item.content || []).filter(c => c.type === "output_text").map(c => c.text).join("\n") || "Maaf, gue belum bisa menjawab.";
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reply }) };
  } catch (e) {
    return { statusCode: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Kesalahan server: " + e.message }) };
  }
};